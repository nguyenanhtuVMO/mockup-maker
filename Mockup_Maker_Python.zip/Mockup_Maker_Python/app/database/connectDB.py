from getpass import getpass
from mysql.connector import connect, Error

